package com.BrainGainz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainGainzApplicationTests {

	@Test
	void contextLoads() {
	}

}
