package com.BrainGainz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrainGainzApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrainGainzApplication.class, args);
	}
}
