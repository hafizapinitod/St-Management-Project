package com.BrainGainz.services;

import java.util.List;

import com.BrainGainz.entity.Course;
import com.BrainGainz.entity.Lesson;

public interface TrainerService {

	
	public String addCourse(Course course);
	public String addLesson(Lesson lesson);
	public Course getCourse(int courseId);
	
	public List<Course> courseList();
	
	
	
	
}
