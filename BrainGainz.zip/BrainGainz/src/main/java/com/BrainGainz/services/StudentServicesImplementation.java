package com.BrainGainz.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BrainGainz.entity.Lesson;
import com.BrainGainz.repository.LessonRepository;

@Service
public class StudentServicesImplementation implements StudentServices{

	@Autowired
	LessonRepository lessonRepo;
	
	
	@Override
	public Lesson getLesson(int lessonId) {
		
		return lessonRepo.findById(lessonId).get();
	}

}
