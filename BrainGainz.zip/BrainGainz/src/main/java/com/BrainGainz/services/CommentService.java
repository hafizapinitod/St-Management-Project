package com.BrainGainz.services;

import java.util.List;

import com.BrainGainz.entity.Comments;

public interface CommentService {

	List<Comments> commentList();
	String addComment(Comments comment);
}
