package com.BrainGainz.services;

import com.BrainGainz.entity.Lesson;

public interface StudentServices {

	
	Lesson getLesson(int lessonId);
}
