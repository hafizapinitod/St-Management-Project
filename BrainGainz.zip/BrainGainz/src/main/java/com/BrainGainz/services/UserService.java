package com.BrainGainz.services;

import com.BrainGainz.entity.Users;

public interface UserService {

	//add new user
	String addUser(Users users);
	
	//check email is already exists in the database
	boolean checkEmail(String email);
	
	
	//validate user credentials
	boolean validate(String email,String password);
	
	//getUser's role by providing email
	String getUserRole(String email);
	
	
}
