package com.BrainGainz.controller;

import java.util.List;

import javax.xml.stream.events.Comment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.BrainGainz.entity.Comments;
import com.BrainGainz.entity.Users;
import com.BrainGainz.services.CommentService;
import com.BrainGainz.services.UserService;

@Controller
public class ServiceController
{
	@Autowired
	UserService uService;
	
	@Autowired
	CommentService cService;

	@PostMapping("/addUser")
	public String addUser(@RequestParam ("name") String name,
			@RequestParam ("email") String email,
			@RequestParam ("password") String password,
			@RequestParam ("role") String role,Model model)
	{
		   boolean emailExists=uService.checkEmail(email);
		   if(emailExists==false)
		   {
		         Users user=new Users();
		         user.setName(name);
		         user.setEmail(email);
		         user.setPassword(password);
	             user.setRole(role);
		         uService.addUser(user);
		         System.out.println("User registered successfully");
		         model.addAttribute("user",user);
	             return "redirect:/login";
	        }
	     	else
	     	{
	     		  System.out.println("User already exists");
		    	   return "redirect:/register";
		    }
	}
	
	   @PostMapping("/validate")
	   public String validate(@RequestParam ("email") String email,
		@RequestParam ("password") String password)
	    {
		   if(uService.checkEmail(email)) 
		   {
			       boolean val=uService.validate(email, password);
			       //if user is valid
		           if(val==true)
	               {
		             	if(uService.getUserRole(email).equals("trainer"))
		             	{
		             		
		             		return "trainerHome";
		             	}
		             	else
		             	{
		             	
		     	        return "studentHome";
		             	}
		           }
		          else
		           {
		     	        System.out.println("Incorrect credentials,try again");
		     	        return "login";
		            }
		
	        }
		    else
		    {
			       return "login";
		    }
	   }  
	   
	   
	   
	   
	   @PostMapping("/addComment")
	   public String comments(@RequestParam("comment") String comment,Model model)
	   {
		   Comments c=new Comments();
		   c.setComment(comment);
		  cService.addComment(c);
		  List<Comments> commentList=cService.commentList();
		  model.addAttribute("Comments",commentList);
		   return "redirect:/";
		   
	   }
	   
	   
}
