package com.BrainGainz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BrainGainz.entity.Course;

public interface CourseRepository  extends JpaRepository<Course,Integer>{

}
