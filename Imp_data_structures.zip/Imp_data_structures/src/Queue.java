import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;


public class Queue extends JFrame {

	private JPanel contentPane;
	private JTextField sizefield;
	private JTextField element;
	private JTextField displaybox;
	private int q[];
	private int size;
	private int r=-1;
	private int f=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					Queue frame = new Queue();
					frame.setVisible(true);
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Queue() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 689, 540);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 128, 255));
		contentPane.setBackground(new Color(255, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblQueueDatastructure = new JLabel("QUEUE DATASTRUCTURE");
		lblQueueDatastructure.setForeground(new Color(255, 0, 128));
		lblQueueDatastructure.setFont(new Font("Algerian", Font.BOLD, 25));
		lblQueueDatastructure.setBounds(179, 10, 366, 34);
		contentPane.add(lblQueueDatastructure);
		
		JLabel lblEnterQueueSize = new JLabel("ENTER QUEUE SIZE");
		lblEnterQueueSize.setForeground(new Color(0, 255, 64));
		lblEnterQueueSize.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterQueueSize.setBounds(32, 66, 190, 34);
		contentPane.add(lblEnterQueueSize);
		
		sizefield = new JTextField();
		sizefield.setBounds(262, 69, 190, 27);
		contentPane.add(sizefield);
		sizefield.setColumns(10);
		
		JLabel lblEnterAnElement = new JLabel("ENTER AN ELEMENT");
		lblEnterAnElement.setForeground(new Color(255, 0, 0));
		lblEnterAnElement.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement.setBounds(32, 189, 198, 34);
		contentPane.add(lblEnterAnElement);
		
		element = new JTextField();
		element.setBounds(272, 192, 190, 27);
		contentPane.add(element);
		element.setColumns(10);
		
		JButton queue = new JButton("CREATE QUEUE");
		queue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO CREATE QUEUE
			 size=Integer.valueOf(sizefield.getText());
				q=new int[size];
				String message="QUEUE of size "+size+" created";
				JOptionPane.showMessageDialog(contentPane,message);
				
			}
		});
		queue.setForeground(new Color(123, 4, 49));
		queue.setFont(new Font("Constantia", Font.BOLD, 20));
		queue.setBounds(157, 122, 187, 40);
		contentPane.add(queue);
		
		JButton insert = new JButton("INSERT");
		insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO INSERT IN QUEUE
				int elem;
				if(r==size-1)
				{
					
					JOptionPane.showMessageDialog(contentPane,"Insertion not possible");
				}
				else
				{
					
					elem=Integer.valueOf(element.getText());
					++r;
					q[r]=elem;
					JOptionPane.showMessageDialog(contentPane,"Insertion succesfull");
					element.setText("");
				}
				
			}
		});
		insert.setForeground(new Color(128, 0, 128));
		insert.setFont(new Font("Constantia", Font.BOLD, 20));
		insert.setBounds(498, 186, 142, 40);
		contentPane.add(insert);
		
		JButton delete = new JButton("DELETE");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DELETE QUEUE
				
				if(r==-1 || f>r)
				{
					JOptionPane.showMessageDialog(contentPane, "Deletion not possible");
				}
				else
				{
					String message="Element deleted is "+q[f];
					JOptionPane.showMessageDialog(contentPane, message);
					f++;
				}
			}
		});
		delete.setForeground(new Color(255, 0, 0));
		delete.setFont(new Font("Constantia", Font.BOLD, 20));
		delete.setBounds(271, 252, 142, 40);
		contentPane.add(delete);
		
		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DISPLAY QUEUE
				String msg="";
				if(r==-1 || f>r)
				{
					JOptionPane.showMessageDialog(contentPane,"Display not possible");
				}
				else
				{
					for(int i=f;i<=r;i++)
					{
						
						msg=msg+" "+q[i];
						
					}
					displaybox.setText(msg);
				}
			}
		});
		display.setForeground(new Color(64, 0, 128));
		display.setFont(new Font("Constantia", Font.BOLD, 20));
		display.setBounds(272, 312, 142, 40);
		contentPane.add(display);
		
		displaybox = new JTextField();
		displaybox.setBackground(new Color(128, 255, 255));
		displaybox.setBounds(157, 386, 388, 34);
		contentPane.add(displaybox);
		displaybox.setColumns(10);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//
				Home home=new Home();
				 home.setVisible(false);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Constantia", Font.BOLD, 25));
		btnNewButton.setBounds(296, 440, 117, 39);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\queueee.jpg"));
		lblNewLabel.setBounds(0, 0, 675, 503);
		contentPane.add(lblNewLabel);
	}
}
