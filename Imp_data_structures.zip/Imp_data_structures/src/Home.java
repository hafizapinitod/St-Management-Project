import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Window;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Home extends JFrame {

	private JPanel contentPane;

	/*
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 683, 400);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBackground(new Color(255, 255, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		JLabel lblChooseADatastructure = new JLabel("CHOOSE A DATA STRUCTURE");
		lblChooseADatastructure.setFont(new Font("Algerian", Font.BOLD, 25));
		lblChooseADatastructure.setBounds(167, 10, 370, 34);
		contentPane.add(lblChooseADatastructure);

		JButton array = new JButton("ARRAY");
		array.setForeground(new Color(0, 0, 255));
		array.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//PLACE ARRAY WINDOW OPENING CODE HERE
				new Array().setVisible(true);
				final String SONG="C:\\Users\\HAFIZA\\eclipse-workspace\\MiniProject\\Audio\\Arrays.mp3";
				final MP3Player mp3player=new MP3Player(new File(SONG));
				mp3player.play();
				
			}
		});
		array.setFont(new Font("Constantia", Font.BOLD, 20));
		array.setBounds(277, 60, 101, 33);
		contentPane.add(array);

		JButton stack = new JButton("STACK");
		stack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//PLACE STACK WINDOW OPENING CODE HERE

				new Stack().setVisible(true);
			}
		});
		stack.setForeground(new Color(255, 128, 0));
		stack.setFont(new Font("Constantia", Font.BOLD, 20));
		stack.setBounds(96, 120, 114, 33);
		contentPane.add(stack);

		JButton queue = new JButton("QUEUE");
		queue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//PLACE QUEUE WINDOW OPENING CODE HERE
				new Queue().setVisible(true);
			}
		});
		queue.setForeground(new Color(255, 128, 192));
		queue.setFont(new Font("Constantia", Font.BOLD, 20));
		queue.setBounds(453, 120, 128, 33);
		contentPane.add(queue);

		JButton cqueue = new JButton("CIRCULAR QUEUE");
		cqueue.setForeground(new Color(0, 255, 0));
		cqueue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//PLACE CIRCULAR QUEUE WINDOW OPENING CODE HERE
				
				new CircularQueue().setVisible(true);
			}
		});
		cqueue.setFont(new Font("Constantia", Font.BOLD, 20));
		cqueue.setBounds(39, 214, 260, 33);
		contentPane.add(cqueue);

		JButton sll = new JButton("SINGLY LINKED LIST");
		sll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//PLACE SINGLY LINKED LIST  WINDOW OPENING CODE HERE
				new SinglyLinkedList().setVisible(true);
			}
		});
		sll.setForeground(new Color(0, 0, 128));
		sll.setFont(new Font("Constantia", Font.BOLD, 20));
		sll.setBounds(373, 214, 260, 33);
		contentPane.add(sll);

		JButton dll = new JButton("DOUBLY LINKED LIST");
		dll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//PLACE DOUBLY LINKED LIST WINDOW OPENING CODE HERE
				new DoublyLinkedList().setVisible(true);
			}
		});
		dll.setForeground(new Color(128, 0, 64));
		dll.setFont(new Font("Constantia", Font.BOLD, 20));
		dll.setBounds(232, 287, 280, 33);
		contentPane.add(dll);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\OneDrive\\Desktop\\array.jpg"));
		lblNewLabel.setBounds(0, 0, 669, 363);
		contentPane.add(lblNewLabel);
	}

	protected Window CircularQueue() {
		// TODO Auto-generated method stub
		return null;
	}
}
