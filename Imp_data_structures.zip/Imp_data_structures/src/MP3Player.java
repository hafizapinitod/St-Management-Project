import java.io.File;

public class MP3Player {

	public MP3Player(File file) {
		// TODO Auto-generated constructor stub
	}

	public void play() {
		// TODO Auto-generated method stub
		
	}

}
