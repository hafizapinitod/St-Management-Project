import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class DoublyLinkedList extends JFrame {

	private JPanel contentPane;
	private JTextField element1;
	private JTextField element2;
	private JTextField displaybox;
	private Node first;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DoublyLinkedList frame = new DoublyLinkedList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public DoublyLinkedList() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 890, 527);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(124, 218, 159));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 6));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel IblDoublyLinkedList = new JLabel("DOUBLY LINKEDLIST DATASTRUCTURE");
		IblDoublyLinkedList.setForeground(new Color(213, 0, 106));
		IblDoublyLinkedList.setFont(new Font("Algerian", Font.BOLD, 25));
		IblDoublyLinkedList.setBounds(154, 25, 483, 31);
		contentPane.add(IblDoublyLinkedList);

		JLabel lblEnterAnElement = new JLabel("ENTER AN ELEMENT");
		lblEnterAnElement.setForeground(new Color(0, 128, 0));
		lblEnterAnElement.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement.setBounds(86, 88, 198, 31);
		contentPane.add(lblEnterAnElement);

		element1 = new JTextField();
		element1.setBounds(333, 87, 227, 31);
		contentPane.add(element1);
		element1.setColumns(10);

		JLabel lblEnterAnElement1 = new JLabel("ENTER AN ELEMENT");
		lblEnterAnElement1.setForeground(new Color(0, 128, 0));
		lblEnterAnElement1.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement1.setBounds(96, 153, 198, 31);
		contentPane.add(lblEnterAnElement1);

		element2 = new JTextField();
		element2.setColumns(10);
		element2.setBounds(333, 152, 227, 31);
		contentPane.add(element2);

		JButton insertfront = new JButton("INSERT FRONT");
		insertfront.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//code to insert at front

				int elem=Integer.valueOf(element2.getText());

				Node newnode=new Node();
				
				newnode.data=elem;
				newnode.nextlink=null;
				newnode.prelink=null;

				if(first==null)
				{
					first=newnode;
				}
				else
				{
					newnode.nextlink=first;
					first.prelink=newnode;
					first=newnode;
				}
				JOptionPane.showMessageDialog(contentPane, "Insetion successful");
				element2.setText("");
			}
		});
		insertfront.setForeground(new Color(0, 0, 128));
		insertfront.setFont(new Font("Constantia", Font.BOLD, 20));
		insertfront.setBounds(618, 141, 185, 47);
		contentPane.add(insertfront);

		JButton deleterear = new JButton("DELETE REAR");
		deleterear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Code to delete at rear
				Node temp;
				if(first==null)
				{

					JOptionPane.showMessageDialog(contentPane,"Deletion not possible" );
				}
				else if(first.nextlink==null)
				{
					String message="Element deleted is"+first.data;
					first=null;
					JOptionPane.showMessageDialog(contentPane,message);
					
				}
				else
				{
					temp=first;
					while(temp.nextlink.nextlink!=null)
					{
						temp=temp.nextlink;
					}

					String message="Element deleted is"+temp.nextlink.data;
					temp.nextlink=null;
					JOptionPane.showMessageDialog(contentPane,message);
				}
			}
		});
		deleterear.setForeground(new Color(0, 64, 64));
		deleterear.setFont(new Font("Constantia", Font.BOLD, 20));
		deleterear.setBounds(357, 194, 185, 47);
		contentPane.add(deleterear);

		JButton deletefront = new JButton("DELETE FRONT");
		deletefront.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//code to delete at front
				if(first==null)
				{
					JOptionPane.showMessageDialog(contentPane,"Deletion not possible" );
				}
				else if(first.nextlink==null)
				{
					String message="Element deleted is"+first.data;
					first=null;
					JOptionPane.showMessageDialog(contentPane,message);
				}
				else
				{
					String message="Element deleted is"+first.data;
					first=first.nextlink;
					first.prelink=null;
					JOptionPane.showMessageDialog(contentPane,message);
				}
			}
		});
		deletefront.setForeground(new Color(0, 64, 64));
		deletefront.setFont(new Font("Constantia", Font.BOLD, 20));
		deletefront.setBounds(357, 259, 185, 47);
		contentPane.add(deletefront);

		JButton displayforward = new JButton("DISPLAY FORWARD");
		displayforward.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//display forward
				String msg="";
				Node temp;
				if(first==null)
				{

					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}
				else if(first.nextlink==null)
				{
					 msg=msg+" "+first.data;
				}
				else
				{
					temp=first;
					while(temp!=null)
					{
						msg=msg+" "+temp.data;
						temp=temp.nextlink;
					}
				}
				displaybox.setText(msg);

			}
		});
		displayforward.setForeground(new Color(255, 0, 0));
		displayforward.setFont(new Font("Constantia", Font.BOLD, 20));
		displayforward.setBounds(166, 316, 264, 47);
		contentPane.add(displayforward);

		JButton displayreverse = new JButton("DISPLAY REVERSE");
		displayreverse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//display reverse
				String msg="";
				Node temp;
				if(first==null)
				{
					
					JOptionPane.showMessageDialog(contentPane,"Display not possible");
				}
				else if(first.nextlink==null)
				{
					msg=msg+" "+first.data;
					
				}
				else
				{
					temp=first;
					while(temp.nextlink!=null)
					{
						temp=temp.nextlink;
					}
					while(temp!=null)
					{
						
						msg=msg+" "+temp.data;
						temp=temp.prelink;
					}
				}
				displaybox.setText(msg);
			}		
		});
		displayreverse.setForeground(new Color(255, 0, 0));
		displayreverse.setFont(new Font("Constantia", Font.BOLD, 20));
		displayreverse.setBounds(496, 316, 250, 47);
		contentPane.add(displayreverse);

		displaybox = new JTextField();
		displaybox.setBounds(248, 373, 410, 38);
		contentPane.add(displaybox);
		displaybox.setColumns(10);
		
		JButton insertrear = new JButton("INSERT REAR");
		insertrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Code to insert at rear
				Node temp;

				int elem=Integer.valueOf(element1.getText());
					
				Node newnode=new Node();
				newnode.data=elem;
				newnode.prelink=null;
				newnode.nextlink=null;

				if(first==null)
				{
					first=newnode;
				}
				else
				{
					temp=first;
					while(temp.nextlink!=null)
					{
						temp=temp.nextlink;
					}
					temp.nextlink=newnode;
					newnode.prelink=temp;
				}
				JOptionPane.showMessageDialog(contentPane, "Insertion sucessful");
				element1.setText("");
			}
		});
		insertrear.setForeground(new Color(0, 0, 128));
		insertrear.setFont(new Font("Constantia", Font.BOLD, 20));
		insertrear.setBounds(618, 80, 185, 47);
		contentPane.add(insertrear);
		
		JButton back = new JButton("BACK");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//home page
				Home home=new Home();
				home.setVisible(false);
				dispose();
			}
		});
		back.setForeground(new Color(128, 0, 128));
		back.setBackground(new Color(255, 128, 192));
		back.setFont(new Font("Constantia", Font.BOLD, 25));
		back.setBounds(396, 430, 111, 38);
		contentPane.add(back);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\slll.jpg"));
		lblNewLabel.setBounds(0, 0, 876, 490);
		contentPane.add(lblNewLabel);
	}
}
