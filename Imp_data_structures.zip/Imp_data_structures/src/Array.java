import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Array extends JFrame {

	private JPanel contentPane;
	private JTextField length;
	private JTextField element;
	private JTextField deleteposition;
	private JTextField insertposition;
	private JTextField displaybox;
	private int arr[];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					Array frame = new Array();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Array() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 847, 532);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 8));

		setContentPane(contentPane);
		contentPane.setLayout(null);


		JLabel lblArrayDatastructure = new JLabel("ARRAY DATASTRUCTURE");
		lblArrayDatastructure.setForeground(new Color(0, 0, 160));
		lblArrayDatastructure.setFont(new Font("Algerian", Font.BOLD, 23));
		lblArrayDatastructure.setBounds(203, 10, 340, 31);
		contentPane.add(lblArrayDatastructure);

		JLabel lbleEnterArrayLength = new JLabel("ENTER ARRAY LENGTH");
		lbleEnterArrayLength.setForeground(new Color(255, 0, 0));
		lbleEnterArrayLength.setFont(new Font("Constantia", Font.BOLD, 18));
		lbleEnterArrayLength.setBounds(107, 68, 206, 23);
		contentPane.add(lbleEnterArrayLength);

		length = new JTextField();
		length.setBounds(393, 63, 178, 31);
		contentPane.add(length);
		length.setColumns(10);

		JButton create = new JButton("CREATE ARRAY");
		create.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//CODE FOR CREATING ARRAY

				int len=Integer.valueOf(length.getText());
				arr=new int[len];
				String message="Array of length "+len+" Created";
				JOptionPane.showMessageDialog(contentPane, message);
			}
		});
		create.setForeground(new Color(128, 0, 64));
		create.setFont(new Font("Constantia", Font.BOLD, 18));
		create.setBounds(248, 109, 183, 33);
		contentPane.add(create);

		JLabel lblInsertAnInteger = new JLabel("INSERT AN INTEGER ELEMENT");
		lblInsertAnInteger.setForeground(new Color(128, 0, 128));
		lblInsertAnInteger.setFont(new Font("Constantia", Font.BOLD, 18));
		lblInsertAnInteger.setBounds(30, 168, 286, 25);
		contentPane.add(lblInsertAnInteger);

		element = new JTextField();
		element.setBounds(319, 164, 140, 31);
		contentPane.add(element);
		element.setColumns(10);

		JButton insert = new JButton("INSERT");
		insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//CODE FOR INSERTION
				int elem=Integer.valueOf(element.getText());
				int pos=Integer.valueOf(insertposition.getText());
				arr[pos]=elem;
				String message="Element "+elem+" inserted @ position "+pos;
				JOptionPane.showMessageDialog(contentPane, message);
				element.setText("");
				insertposition.setText("");
			}
		});
		insert.setForeground(new Color(64, 0, 128));
		insert.setFont(new Font("Constantia", Font.BOLD, 18));
		insert.setBounds(705, 165, 118, 31);
		contentPane.add(insert);

		JLabel lblDeletePosition = new JLabel("DELETE POSITION");
		lblDeletePosition.setForeground(new Color(255, 0, 128));
		lblDeletePosition.setFont(new Font("Constantia", Font.BOLD, 18));
		lblDeletePosition.setBounds(30, 249, 183, 25);
		contentPane.add(lblDeletePosition);

		deleteposition = new JTextField();
		deleteposition.setBounds(248, 245, 140, 31);
		contentPane.add(deleteposition);
		deleteposition.setColumns(10);

		insertposition = new JTextField();
		insertposition.setBounds(590, 166, 96, 27);
		contentPane.add(insertposition);
		insertposition.setColumns(10);

		JLabel lblPosition = new JLabel("POSITION");
		lblPosition.setFont(new Font("Constantia", Font.BOLD, 18));
		lblPosition.setForeground(new Color(255, 128, 64));
		lblPosition.setBounds(480, 168, 91, 24);
		contentPane.add(lblPosition);

		JButton delete = new JButton("DELETE");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//CODE FOR DELETION
				int pos=Integer.valueOf(deleteposition.getText());
				arr[pos]=0;
				String message="Element deleted @ the poition "+pos;
				JOptionPane.showMessageDialog(contentPane, message);
				deleteposition.setText("");
			}
		});
		delete.setForeground(new Color(0, 128, 64));
		delete.setFont(new Font("Constantia", Font.BOLD, 18));
		delete.setBounds(468, 246, 103, 31);
		contentPane.add(delete);

		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//CODE FOR DISPLAY
				String msg="";
				for (int i = 0; i <=arr.length-1; i++) {
					msg=msg+" "+arr[i];	
				}
				displaybox.setText(msg);
			}
		});
		display.setForeground(new Color(128, 0, 64));
		display.setFont(new Font("Constantia", Font.BOLD, 18));
		display.setBounds(293, 326, 138, 31);
		contentPane.add(display);

		displaybox = new JTextField();
		displaybox.setBackground(new Color(128, 255, 255));
		displaybox.setBounds(170, 378, 419, 33);
		contentPane.add(displaybox);
		displaybox.setColumns(10);

		JButton btnNewButton = new JButton("BACK");
		btnNewButton.setForeground(new Color(0, 128, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Home home=new Home();
			    home.setVisible(false);
			 	dispose();
			}
		});
		btnNewButton.setFont(new Font("Constantia", Font.BOLD | Font.ITALIC, 25));
		btnNewButton.setBounds(334, 421, 108, 45);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\arrayyy.jpg"));
		lblNewLabel.setBounds(10, 10, 813, 475);
		contentPane.add(lblNewLabel);
	}
}
