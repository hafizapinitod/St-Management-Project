import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class CircularQueue extends JFrame {

	private JPanel contentPane;
	private JTextField sizefield;
	private JTextField element;
	private JTextField displaybox;
	private int cq[];
	private int size;
	private int r=-1;
	private int f=0;
	private int count=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CircularQueue frame = new CircularQueue();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CircularQueue() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 805, 536);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("CIRCULAR QUEUE DATASTRUCTURE");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 25));
		lblNewLabel.setBounds(149, 10, 444, 34);
		contentPane.add(lblNewLabel);

		JLabel lblEnterQueueSize = new JLabel("ENTER QUEUE SIZE");
		lblEnterQueueSize.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterQueueSize.setForeground(new Color(255, 0, 0));
		lblEnterQueueSize.setBounds(80, 62, 206, 34);
		contentPane.add(lblEnterQueueSize);

		sizefield = new JTextField();
		sizefield.setBackground(new Color(255, 128, 255));
		sizefield.setBounds(340, 64, 206, 30);
		contentPane.add(sizefield);
		sizefield.setColumns(10);

		JLabel lblEnterAnElement = new JLabel("ENTER AN ELEMENT");
		lblEnterAnElement.setForeground(new Color(64, 0, 128));
		lblEnterAnElement.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement.setBounds(80, 189, 206, 34);
		contentPane.add(lblEnterAnElement);

		element = new JTextField();
		element.setBackground(new Color(255, 128, 255));
		element.setBounds(305, 191, 192, 30);
		contentPane.add(element);
		element.setColumns(10);

		JButton queue = new JButton("CREATE QUEUE");
		queue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO CREATE CIRCULAR QUEUE
				size=Integer.valueOf(sizefield.getText());
				cq=new int[size];
				String message="Queue of size "+size+" created";
				JOptionPane.showMessageDialog(contentPane, message);

			}
		});
		queue.setForeground(new Color(0, 128, 0));
		queue.setFont(new Font("Constantia", Font.BOLD, 20));
		queue.setBounds(186, 108, 206, 44);
		contentPane.add(queue);

		JButton insert = new JButton("INSERT");
		insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO INSERT INTO CQ
				int elem;
				if(count==size)
				{
					JOptionPane.showMessageDialog(contentPane, "Insertion not possible");
				}
				else
				{
					elem=Integer.valueOf(element.getText());				
					r=(r+1)%size;
					cq[r]=elem;
					++count;
					JOptionPane.showMessageDialog(contentPane,"Insertion successful");
					element.setText("");
				}
			}
		});
		insert.setForeground(new Color(255, 128, 0));
		insert.setFont(new Font("Constantia", Font.BOLD, 20));
		insert.setBounds(538, 181, 149, 44);
		contentPane.add(insert);

		JButton delete = new JButton("DELETE");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DELETE FROM CQ
				
				if(count==0)
				{
				
					JOptionPane.showMessageDialog(contentPane,"Deletion not possible" );
				}
				else
				{
					String message="Element deleted is"+cq[f];
					f=(f+1)%size;
					--count;
					JOptionPane.showMessageDialog(contentPane, message);
				}
			}
		});
		delete.setForeground(new Color(205, 50, 151));
		delete.setFont(new Font("Constantia", Font.BOLD, 20));
		delete.setBounds(330, 246, 149, 44);
		contentPane.add(delete);

		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DISPLAY THE CQ
				String msg="";
				int f1=f;
				if(count==0)
				{
					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}
				else
				{
					for(int i=1;i<=count;i++)
					{
						msg=msg+" "+cq[f1];	
						f1=(f1+1)%size;
					}
					displaybox.setText(msg);
				}

			}
		});
		display.setForeground(new Color(0, 0, 160));
		display.setFont(new Font("Constantia", Font.BOLD, 20));
		display.setBounds(330, 319, 149, 44);
		contentPane.add(display);

		displaybox = new JTextField();
		displaybox.setBackground(new Color(255, 128, 255));
		displaybox.setBounds(242, 381, 351, 34);
		contentPane.add(displaybox);
		displaybox.setColumns(10);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//
				Home home=new Home();
				 home.setVisible(false);
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setFont(new Font("Constantia", Font.BOLD, 25));
		btnNewButton.setBounds(352, 439, 127, 39);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\cqqq.jpg"));
		lblNewLabel_1.setBounds(0, 0, 791, 499);
		contentPane.add(lblNewLabel_1);
	}
}
