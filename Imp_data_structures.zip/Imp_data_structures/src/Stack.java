import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Stack extends JFrame {

	private JPanel contentPane;
	private JTextField sizefield;
	private JTextField element;
	private JTextField displaybox;
	private int s[];
	private int size;
	private int top=-1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					Stack frame = new Stack();
					frame.setVisible(true);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Stack() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 695, 538);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 253, 2));
		contentPane.setBorder(new LineBorder(new Color(64, 0, 64), 4));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblStackDatastructure = new JLabel("STACK DATASTRUCTURE");
		lblStackDatastructure.setForeground(new Color(64, 0, 64));
		lblStackDatastructure.setFont(new Font("Algerian", Font.BOLD, 25));
		lblStackDatastructure.setBounds(168, 10, 299, 34);
		contentPane.add(lblStackDatastructure);
		
		JLabel lblEnterStackSize = new JLabel("ENTER STACK SIZE");
		lblEnterStackSize.setForeground(new Color(255, 0, 0));
		lblEnterStackSize.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterStackSize.setBounds(26, 72, 204, 34);
		contentPane.add(lblEnterStackSize);
		
		sizefield = new JTextField();
		sizefield.setBounds(255, 72, 212, 30);
		contentPane.add(sizefield);
		sizefield.setColumns(10);
		
		JButton stack = new JButton("CREATE STACK");
		stack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Stack creation code
				size=Integer.valueOf(sizefield.getText());//taking text from user
				s=new int[size];
				String message="Stack of size "+size+" created";
				JOptionPane.showMessageDialog(contentPane, message);
			}
		});
		stack.setForeground(new Color(64, 0, 128));
		stack.setFont(new Font("Constantia", Font.BOLD, 20));
		stack.setBounds(149, 116, 204, 49);
		contentPane.add(stack);
		
		JLabel lblEnterAnElement = new JLabel("ENTER AN ELEMENT");
		lblEnterAnElement.setForeground(new Color(128, 0, 128));
		lblEnterAnElement.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement.setBounds(26, 192, 198, 25);
		contentPane.add(lblEnterAnElement);
		
		element = new JTextField();
		element.setBounds(255, 189, 212, 30);
		contentPane.add(element);
		element.setColumns(10);
		
		JButton push = new JButton("PUSH");
		push.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//PUSH OPERATION CODE
				int elem;
				if(top==size-1)
				{
					JOptionPane.showMessageDialog(contentPane, "PUSH not possible");
				}
				else
				{
					 elem=Integer.valueOf(element.getText());
					++top;
					s[top]=elem;
					JOptionPane.showMessageDialog(contentPane,"PUSH successful");
					element.setText("");
				}
				
			}
		});
		push.setForeground(new Color(255, 0, 128));
		push.setFont(new Font("Constantia", Font.BOLD, 20));
		push.setBounds(526, 187, 110, 34);
		contentPane.add(push);
		
		JButton pop = new JButton("POP");
		pop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//POP OPERATION CODE
				if(top==-1)
				{
					JOptionPane.showMessageDialog(contentPane,"POP not posssible");
				}
				else
				{
					String message="Element deleted is"+s[top];
					JOptionPane.showMessageDialog(contentPane, message);
					--top;
				}
			}
		});
		pop.setForeground(new Color(128, 0, 0));
		pop.setFont(new Font("Constantia", Font.BOLD, 20));
		pop.setBounds(279, 248, 141, 41);
		contentPane.add(pop);
		
		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//DISPLAY OPERATION CODE
				String msg="";
				if(top==-1)
				{
					JOptionPane.showMessageDialog(contentPane, "DISPLAY not possible");
				}
				else
				{
					for(int i=top;i>=0;i--)
					{
						msg=msg+" "+s[i];
					}
					displaybox.setText(msg);
				}
			}
		});
		display.setForeground(new Color(0, 128, 0));
		display.setFont(new Font("Constantia", Font.BOLD, 20));
		display.setBounds(279, 306, 150, 41);
		contentPane.add(display);
		
		displaybox = new JTextField();
		displaybox.setBackground(new Color(255, 255, 255));
		displaybox.setBounds(178, 370, 371, 34);
		contentPane.add(displaybox);
		displaybox.setColumns(10);
		
		JButton button = new JButton("BACK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Home home=new Home();
				 home.setVisible(false);
				dispose();
			}
		});
		button.setFont(new Font("Constantia", Font.BOLD, 25));
		button.setBounds(305, 438, 115, 39);
		contentPane.add(button);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\stack.jpg"));
		lblNewLabel.setBounds(0, 0, 681, 501);
		contentPane.add(lblNewLabel);
	}
}
