
public class Node {

	protected int data;
	protected Node link;
	protected Node prelink;
	protected Node nextlink;
}
