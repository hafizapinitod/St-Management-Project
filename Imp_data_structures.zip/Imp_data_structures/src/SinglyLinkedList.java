import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.border.LineBorder;

import org.w3c.dom.Text;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class SinglyLinkedList extends JFrame {

	protected static final Node Node= null;
	private JPanel contentPane;
	private JTextField element1;
	private JTextField element2;
	private JTextField displaybox;
	private Node first;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					SinglyLinkedList frame = new SinglyLinkedList();
					frame.setVisible(true);
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SinglyLinkedList() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 846, 525);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 128, 128));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 7));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("SINGLY LINKED LIST DATASTRUCTURE");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 25));
		lblNewLabel.setBounds(203, 10, 457, 34);
		contentPane.add(lblNewLabel);

		JLabel lblEnterAnElement1 = new JLabel("ENTER AN ELEMENT ");
		lblEnterAnElement1.setBackground(new Color(64, 0, 128));
		lblEnterAnElement1.setForeground(new Color(0, 0, 128));
		lblEnterAnElement1.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement1.setBounds(46, 77, 216, 25);
		contentPane.add(lblEnterAnElement1);

		element1 = new JTextField();
		element1.setBounds(294, 72, 175, 34);
		contentPane.add(element1);
		element1.setColumns(10);

		JButton insertrear = new JButton("INSERT REAR");
		insertrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO INSERT AT REAR
				int data;
				Node link;

				Node temp;
				int elem=Integer.valueOf(element1.getText());

				Node newnode=new Node();
				newnode.data=elem;
				newnode.link=null;

				if(first==null)
				{
					first=newnode;
				}
				else
				{
					temp=first;
					while(temp.link!=null)
					{
						temp=(Node) temp.link;
					}
					temp.link=newnode;
				}	
				JOptionPane.showMessageDialog(contentPane,"Insertion succesfull");
				element1.setText("");
			}
		});
		insertrear.setForeground(new Color(0, 0, 128));
		insertrear.setFont(new Font("Constantia", Font.BOLD, 20));
		insertrear.setBounds(546, 72, 197, 34);
		contentPane.add(insertrear);

		JLabel lblEnterAnElement2 = new JLabel("ENTER AN ELEMENT ");
		lblEnterAnElement2.setForeground(new Color(0, 128, 64));
		lblEnterAnElement2.setFont(new Font("Constantia", Font.BOLD, 20));
		lblEnterAnElement2.setBackground(new Color(64, 0, 128));
		lblEnterAnElement2.setBounds(46, 127, 216, 25);
		contentPane.add(lblEnterAnElement2);

		element2 = new JTextField();
		element2.setColumns(10);
		element2.setBounds(294, 127, 175, 34);
		contentPane.add(element2);

		JButton insertfront = new JButton("INSERT FRONT");
		insertfront.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO INSERT AT FRONT
				int elem2=Integer.valueOf(element2.getText());
				Node newnode=new Node();
				newnode.data=elem2;
				newnode.link=null;

				if(first==null)
				{
					first=newnode;
				}
				else
				{
					newnode.link=first;
					first=newnode;
				}
				JOptionPane.showMessageDialog(contentPane,"Insertion  succesfull");
				element2.setText("");
			}
		});
		insertfront.setForeground(new Color(0, 128, 64));
		insertfront.setFont(new Font("Constantia", Font.BOLD, 20));
		insertfront.setBounds(556, 122, 197, 34);
		contentPane.add(insertfront);

		JButton deleterear = new JButton("DELETE REAR");
		deleterear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DELETE REAR
				Node temp;
				if(first==null)
				{
					JOptionPane.showMessageDialog(contentPane,"Deletion not possible" );
				}
				if(first.link==null)
				{

					String message="Element deleted is"+first.data;
					first=null;
				}
				else
				{
					temp=first;
					while(temp.link.link!=null)
					{
						temp=temp.link;
					}

					String message="Element deleted is"+temp.link.data;
					temp.link=null;
					JOptionPane.showMessageDialog(contentPane,message);
				}

			}
		});
		deleterear.setForeground(new Color(255, 0, 0));
		deleterear.setFont(new Font("Constantia", Font.BOLD, 20));
		deleterear.setBounds(293, 183, 197, 34);
		contentPane.add(deleterear);

		JButton deletefront = new JButton("DELETE FRONT");
		deletefront.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DELETE FRONT
				if(first==null)
				{
					JOptionPane.showMessageDialog(contentPane,"Deletion not possible" );

				}
				else if(first.link==null)
				{
					first=null;
				}
				else
				{
					String message="Element deleted is"+first.data;
					first=first.link;
					JOptionPane.showMessageDialog(contentPane,message);
				}

			}
		});
		deletefront.setForeground(new Color(0, 128, 128));
		deletefront.setFont(new Font("Constantia", Font.BOLD, 20));
		deletefront.setBounds(293, 237, 197, 34);
		contentPane.add(deletefront);

		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//CODE TO DISPLAY
				String msg="";
				Node temp;
				if(first==null)
				{
					
					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}
				else if(first.link==null)
				{
					msg=msg+" "+first.data;	
				}
				else
				{
					temp=first;
					while(temp!=null)
					{
						msg=msg+" "+temp.data;
						temp=temp.link;
					}
					displaybox.setText(msg);
				}
			}
		});
		display.setForeground(new Color(0, 0, 64));
		display.setFont(new Font("Constantia", Font.BOLD, 20));
		display.setBounds(294, 302, 197, 34);
		contentPane.add(display);

		displaybox = new JTextField();
		displaybox.setBounds(203, 361, 395, 34);
		contentPane.add(displaybox);
		displaybox.setColumns(10);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//
				Home home=new Home();
				 home.setVisible(false);
				dispose();
			}
		});
		btnBack.setForeground(new Color(128, 0, 128));
		btnBack.setFont(new Font("Constantia", Font.BOLD, 25));
		btnBack.setBounds(347, 418, 121, 39);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\HAFIZA\\Downloads\\images\\sllllllllllllllllll.jpg"));
		lblNewLabel_1.setBounds(0, 0, 832, 488);
		contentPane.add(lblNewLabel_1);
	}
}
