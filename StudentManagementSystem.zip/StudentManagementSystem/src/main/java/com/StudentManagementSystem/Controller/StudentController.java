package com.StudentManagementSystem.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.StudentManagementSystem.entity.Student;
import com.StudentManagementSystem.services.StudentService;

import org.springframework.ui.Model;

@RestController
@RequestMapping("/stud")
public class StudentController {

	StudentService ss;

	public StudentController(StudentService ss) {
		super();
		this.ss = ss;
	}
	
	@PostMapping("/addstud")
	public String addStudent(@RequestParam ("kodId") String kodId,@RequestParam ("name") String name,@RequestParam ("branch") String branch )
	{
		Student s=new Student(kodId,name,branch);
		ss.addStudent(s);
		return "index";
	}
	
	@GetMapping(value="{kodId}")
	public Student getStudent(@PathVariable("kodId") String kodId)
	{
		Student s=ss.getStudent(kodId);
		return s;
	}
	
	@GetMapping
	public List<Student> getAllStudents(Model model)
	{
		List<Student> slist=ss.getAllStudents();
		model.addAttribute("list",slist);
		return slist;
	}
	
	@PutMapping("/updstud")
	public String updateStudent(@RequestParam ("kodId") String kodId,@RequestParam ("name") String name,@RequestParam ("branch") String branch )
	{
		Student st=ss.getStudent(kodId);
		st.setName(name);
		st.setBranch(branch);
		ss.updateStudent(st);
		
		return "index";
	}
	
	@DeleteMapping(value="{kodId}")
	public String deleteStudent(@PathVariable("kodId") String kodId)
	{
		String msg=ss.deleteStudent(kodId);
		return msg;
	}
	
}
