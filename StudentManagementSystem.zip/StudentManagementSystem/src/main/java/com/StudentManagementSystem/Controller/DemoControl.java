package com.StudentManagementSystem.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DemoControl {

	@GetMapping("viewIn")
	public String mapViewInfo()
	{
		return "viewInfo";
	}
	
	@GetMapping("addIn")
	public String addInfo()
	{
		return "addInfo";
	}
	
	@GetMapping("updateIn")
	public String updateInfo()
	{
		return "updateInfo";
	}
	
	@GetMapping("removeIn")
	public String removeInfo()
	{
		return "removeInfo";
	}
  
	@GetMapping("showIn")
	public String showInfo()
	{
		return "showInfo";
	}
	
	
}
