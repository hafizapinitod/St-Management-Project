package com.StudentManagementSystem.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.StudentManagementSystem.entity.Student;
import com.StudentManagementSystem.repository.StudentRepository;

@Service
public class StudentServiceImplementation implements StudentService {

	StudentRepository srepo;

	public StudentServiceImplementation(StudentRepository srepo) {
		super();
		this.srepo = srepo;
	}

	@Override
	public String addStudent(Student s) {     //localhost:9888/stud   --put
		srepo.save(s);
		return "Student added successfully";
	}

	@Override
	public Student getStudent(String kodId) {		//localhost:9888/stud/kod111 --get
		Student st=srepo.findById(kodId).get();
		return st;
	}

	@Override
	public List<Student> getAllStudents() {             //http://localhost:9888/stud  --get
		List<Student> slist=srepo.findAll();
		return slist;
		
	}

	@Override
	public String updateStudent(Student s) {                  //http://localhost:9888/stud --put
		srepo.save(s);
		return "Student updated successfully";
	}

	@Override
	public String deleteStudent(String kodId) {           // http://localhost:9888/stud/kod12  --delete
	srepo.deleteById(kodId);
		return "Student deleted successfully";
	}

}
