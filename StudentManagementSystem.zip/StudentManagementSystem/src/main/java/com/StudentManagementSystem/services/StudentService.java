package com.StudentManagementSystem.services;

import java.util.List;

import com.StudentManagementSystem.entity.Student;

public interface StudentService {

	String addStudent(Student s);
	Student getStudent(String kodId);
	List<Student> getAllStudents();
	String updateStudent(Student s);
	String deleteStudent(String kodId);
}
